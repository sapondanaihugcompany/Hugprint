Name = "poom";
Salary = 14000;
tax = 0.7;

print("Salary")